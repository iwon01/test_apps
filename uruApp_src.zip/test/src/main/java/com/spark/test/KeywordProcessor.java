package com.spark.test;

import java.sql.SQLException;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.jaunt.*;
import com.mashape.unirest.http.exceptions.UnirestException;

public class KeywordProcessor {
	private Database db;
	private ImaggaRestCaller caller;
	
	public KeywordProcessor(){
		this.db = Database.getDBInstance();
		this.caller = new ImaggaRestCaller();
	}
	
	public int process(String keyword){
		int key = 0;
		try {
			UserAgent userAgent = new UserAgent();
			userAgent.visit("http://www.google.com/search?tbm=isch&q=" + keyword);
			Element element = userAgent.doc.findFirst("<table class='images_table'>");
			Element img = element.findFirst("<img>");
			String url = img.getAtString("src");
			System.out.println(url);
			key = db.insertImage(url);
			
			caller = new ImaggaRestCaller();
			String jsonString = caller.getTagsFromImageJson(url);
			JSONParser parser = new JSONParser();
			JSONObject object = (JSONObject) parser.parse(jsonString);
			JSONArray results = (JSONArray) object.get("results");
			JSONObject imageInfo = (JSONObject) results.get(0);
			JSONArray tags = (JSONArray) imageInfo.get("tags");
			
			Iterator iter = tags.iterator();			
			while(iter.hasNext()){
				JSONObject tagObject = (JSONObject) iter.next();
				db.insertImageTags(key, (String)tagObject.get("tag"));
			}
			
			System.out.println("IMAGES:");
			List<Map<String,Object>> resultList = db.getImages();
			for (Map<String,Object> row : resultList){
				System.out.println("ID: " + row.get("id") + ", URL: " + row.get("url"));
			}
			
			System.out.println();
			System.out.println("IMAGE TAGS:");
			resultList = db.getImageTags(key);
			for (Map<String,Object> row : resultList){
				System.out.println("ID: " + row.get("id") + ", TAG: " + row.get("tag"));
			}
			
		} catch (JauntException e) {
			e.printStackTrace();
		} catch (UnirestException e){
			e.printStackTrace();
		} catch (SQLException e){
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return key;
	}
	
	public List<Map<String,Object>> getImagesSearched(){
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try {
			list = db.getImages();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public String getImageUrl(int id){
		String url = "";
		try {
			url = db.getImageUrl(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return url;
	}
	
	public List<Map<String,Object>> getTagsFromId(int id){
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try {
			list = db.getImageTags(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
}
