package com.spark.test;

import java.util.*;

import spark.ModelAndView;
import spark.template.velocity.*;

import static spark.Spark.*;

public class App 
{
	private KeywordProcessor processor = new KeywordProcessor();
	
	public int process(String keyword){
		return processor.process(keyword);
	}
	public List<Map<String,Object>> getImagesSearched(){
		return processor.getImagesSearched();
	}
	public String getImageUrl(int id){
		return processor.getImageUrl(id);
	}
	public List<Map<String,Object>> getTagsFromId(int id){
		return processor.getTagsFromId(id);
	}
	
    public static void main( String[] args )
    {
    	App app = new App();
        get("/", (req, res) -> {
        	HashMap<String,Object> model = new HashMap<String,Object>();
        	return new ModelAndView(model, "form.vm");
        }, new VelocityTemplateEngine());
        
        post("/postForImage", (req, res) ->  {
        	String keyword = req.queryParams("keyword");
        	System.out.println(keyword);
        	int key = app.process(keyword);
        	res.redirect("/imageTags/"+key);
        	return "";
        });
        
        get("/imagesSearched", (req, res) -> {
        	HashMap<String,Object> model = new HashMap<String,Object>();
        	model.put("list", app.getImagesSearched());
        	return new ModelAndView(model, "imagesSearched.vm");
        }, new VelocityTemplateEngine());
        
        get("/imageTags/:id", (req, res) -> {
        	String s_id = req.params(":id");
        	System.out.println(s_id);
        	Integer id = Integer.parseInt(s_id);
        	HashMap<String,Object> model = new HashMap<String,Object>();
        	model.put("url", app.getImageUrl(id));
        	model.put("list", app.getTagsFromId(id));
        	return new ModelAndView(model, "imageTags.vm");
        }, new VelocityTemplateEngine());
        
        get("/stop", (request, response) -> {
        	stop();
        	return "stop";
        });
    }
}
