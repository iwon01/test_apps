package com.spark.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import org.h2.tools.DeleteDbFiles;

public class Database {
	private static final String DB_DRIVER = "org.h2.Driver";
    private static final String DB_CONNECTION = "jdbc:h2:~/test";
    private static final String DB_USER = "";
    private static final String DB_PASSWORD = "";
    
    private static Database db = null;
    
    private int keyCounter = 0;
	
    private Database(){
    	try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public static Database getDBInstance(){
    	if (db == null) {
    		db = new Database();
    		try {
    			DeleteDbFiles.execute("~", "test", true);
				db.createTables();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}
    	return db;
    }
    
	private Connection getDBConnection() {
        Connection dbConnection = null;
        
        try {
            dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dbConnection;
    }
	
	public void createTables() throws SQLException{
		Connection connection = getDBConnection();
	    PreparedStatement createPreparedStatement = null;
        
        String createImagesTable = "CREATE TABLE IMAGES(id int primary key, url varchar(255))";
        String createImageTagsTable = "CREATE TABLE IMAGE_TAGS(id int, tag varchar(100), foreign key (id) references IMAGES(id))";
        
        try {
            connection.setAutoCommit(false);
           
            createPreparedStatement = connection.prepareStatement(createImagesTable);
            createPreparedStatement.executeUpdate();
            createPreparedStatement.close();
            
            createPreparedStatement = connection.prepareStatement(createImageTagsTable);
            createPreparedStatement.executeUpdate();
            createPreparedStatement.close();
           
            connection.commit();
        } catch (SQLException e) {
            System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }

	}
	
	public int insertImage(String url) throws SQLException{
		Connection connection = getDBConnection();
		PreparedStatement insertPreparedStatement = null;
        
        String insertImageQuery = "INSERT INTO IMAGES" + "(id, url) values" + "(?,?)";
        
        try {
            connection.setAutoCommit(false);
            
            insertPreparedStatement = connection.prepareStatement(insertImageQuery);
            insertPreparedStatement.setInt(1, keyCounter);
            insertPreparedStatement.setString(2, url);
            insertPreparedStatement.executeUpdate();
            insertPreparedStatement.close();
            
            connection.commit();
        } catch (SQLException e){
        	System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.close();
        }
        
        return keyCounter++;
	}
	
	public void insertImageTags(int id, String tag) throws SQLException{
		Connection connection = getDBConnection();
		PreparedStatement insertPreparedStatement = null;
        
        String insertImageTagQuery = "INSERT INTO IMAGE_TAGS" + "(id, tag) values" + "(?,?)";
        
        try {
            connection.setAutoCommit(false);
            
            insertPreparedStatement = connection.prepareStatement(insertImageTagQuery);
            insertPreparedStatement.setInt(1, id);
            insertPreparedStatement.setString(2, tag);
            insertPreparedStatement.executeUpdate();
            
            connection.commit();
        } catch (SQLException e){
        	System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        	insertPreparedStatement.close();
            connection.close();
        }
	}
	
	public List<Map<String,Object>> getImages() throws SQLException{
		Connection connection = getDBConnection();
		PreparedStatement selectPreparedStatement = null;
		ResultSet rs = null;
		
		String selectImageQuery = "select * from IMAGES";
		
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try {
            connection.setAutoCommit(false);
            selectPreparedStatement = connection.prepareStatement(selectImageQuery);
            rs = selectPreparedStatement.executeQuery();
            
            while(rs.next()){
            	Map<String,Object> row = new HashMap<String,Object>();
            	row.put("id", rs.getInt("id"));
            	row.put("url", rs.getString("url"));
            	list.add(row);
            }
          
            connection.commit();
		} catch (SQLException e){
        	System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        	rs.close();
        	selectPreparedStatement.close();
            connection.close();
        }
		
		return list;
	}
	
	public String getImageUrl(int id) throws SQLException{
		Connection connection = getDBConnection();
		PreparedStatement selectPreparedStatement = null;
		ResultSet rs = null;
		
		String selectImageQuery = "select url from IMAGES where id = ?";
		
		String url = "";
		try {
            connection.setAutoCommit(false);
            selectPreparedStatement = connection.prepareStatement(selectImageQuery);
            selectPreparedStatement.setInt(1, id);
            rs = selectPreparedStatement.executeQuery();
            
            while(rs.next()){
            	url = rs.getString("url");
            }
          
            connection.commit();
		} catch (SQLException e){
        	System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        	rs.close();
        	selectPreparedStatement.close();
            connection.close();
        }
		
		return url;
	}
	
	public List<Map<String,Object>> getImageTags(int id) throws SQLException{
		Connection connection = getDBConnection();
		PreparedStatement selectPreparedStatement = null;
		ResultSet rs = null;
		
		String selectImageTagsQuery = "select * from IMAGE_TAGS where id = ?";
		
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try {
            connection.setAutoCommit(false);
            selectPreparedStatement = connection.prepareStatement(selectImageTagsQuery);
            selectPreparedStatement.setInt(1, id);
            rs = selectPreparedStatement.executeQuery();
            
            while(rs.next()){
            	Map<String,Object> row = new HashMap<String,Object>();
            	row.put("id", rs.getInt("id"));
            	row.put("tag", rs.getString("tag"));
            	list.add(row);
            }
            
            connection.commit();
		} catch (SQLException e){
        	System.out.println("Exception Message " + e.getLocalizedMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        	rs.close();
        	selectPreparedStatement.close();
            connection.close();
        }
		
		return list;
	}
	

}
