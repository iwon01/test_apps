package com.spark.test;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class ImaggaRestCaller {
	
	private String apiKey = "acc_437e3cbbdc84c0e";
	private String apiSecret = "202ffc46237c73bbdc7677da93af4b85";
	
	public String getTagsFromImageJson(String url) throws UnirestException{
		
		HttpResponse response = Unirest.get("https://api.imagga.com/v1/tagging")
				.queryString("url", url)
				.basicAuth(apiKey, apiSecret)
				.header("Accept", "application/json")
				.asJson();
		
		Object jsonResponse = response.getBody();
		return jsonResponse.toString();
	}


}
